<template>
  <div id="app">
    <app-action />
  </div>
</template>

<script>
import AppAction from "@/components/Action.vue";

export default {
  name: "App",
  components: {
    AppAction,
  },
};
</script>

<style src="bootstrap/dist/css/bootstrap.css"></style>
